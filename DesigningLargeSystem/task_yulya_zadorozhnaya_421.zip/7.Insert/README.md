Для запуска:

```
chmod ugo+x froze.sh
./froze.sh
```
